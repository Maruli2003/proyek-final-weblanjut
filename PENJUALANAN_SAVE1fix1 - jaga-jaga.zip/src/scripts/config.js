const CONFIG = {
  BASE_URL: 'https://story-api.dicoding.dev/v1',
  DATABASE_NAME: 'jualan-online-db',
  DATABASE_VERSION: 1,
  OBJECT_STORE_NAME: 'stories',
  OUTBOX_OBJECT_STORE_NAME: 'outbox',
};

export default CONFIG;
