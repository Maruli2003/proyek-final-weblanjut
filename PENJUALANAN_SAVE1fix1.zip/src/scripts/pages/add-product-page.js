import L from 'leaflet';
import Api from '../data/api';

const AddProductPage = {
  async render() {
    return `
      <section class="content">
        <div class="form-container">
          <h2>Tambah Produk Baru</h2>
          <p class="form-subtitle">Isi detail produk Anda di bawah ini untuk menambahkannya ke dalam daftar.</p>
          <form id="add-product-form" class="add-product-form" novalidate>
            
            <div class="form-group">
              <label for="product-name">Nama Produk</label>
              <input type="text" id="product-name" name="product-name" required placeholder="Contoh: Kopi Robusta Pilihan">
            </div>
            
            <div class="form-group">
              <label for="product-description">Deskripsi</label>
              <textarea id="product-description" name="description" rows="4" required placeholder="Jelaskan keunggulan dan detail produk Anda..."></textarea>
            </div>
            
            <div class="form-group">
              <label for="product-photo">Foto Produk</label>
              <input type="file" id="product-photo" name="photo" accept="image/*" required>
              <div class="camera-section">
                <p>Atau ambil langsung dari kamera:</p>
                <div class="camera-wrapper">
                  <video id="camera-preview" width="300" height="225" autoplay muted style="display:none;"></video>
                  <canvas id="camera-canvas" style="display:none;"></canvas>
                  <button type="button" id="start-camera-btn" class="camera-btn">
                    <i class="fas fa-camera"></i> Buka Kamera
                  </button>
                  <button type="button" id="capture-image-btn" class="camera-btn capture-btn" style="display:none;">
                    <i class="fas-regular fa-circle-dot"></i> Ambil Gambar
                  </button>
                </div>
              </div>
            </div>
            
            <div class="form-group">
              <label>Pilih Lokasi di Peta</label>
              <div id="map-picker" style="height: 300px; width: 100%; border-radius: 8px;"></div>
              <input type="hidden" id="latitude" name="lat">
              <input type="hidden" id="longitude" name="lon">
              <p class="location-display">Lokasi Terpilih: <span id="selected-location">-</span></p>
            </div>
            
            <button type="submit" class="submit-btn">
                <i class="fas fa-plus-circle"></i> Tambah Produk
            </button>
          </form>
        </div>
      </section>
      <!-- Font Awesome for icons -->
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">
    `;
  },

  async afterRender() {
    this._initMapPicker();
    this._initCamera();
    this._initFormSubmit();
  },

  _initMapPicker() {
    // Fungsi ini tidak berubah, biarkan seperti sebelumnya
    const map = L.map('map-picker').setView([-6.2088, 106.8456], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(map);

    let marker;
    const latInput = document.querySelector('#latitude');
    const lonInput = document.querySelector('#longitude');
    const locationDisplay = document.querySelector('#selected-location');

    map.on('click', (e) => {
      const { lat, lng } = e.latlng;
      
      if (marker) {
        map.removeLayer(marker);
      }

      marker = L.marker([lat, lng]).addTo(map);
      latInput.value = lat;
      lonInput.value = lng;
      locationDisplay.textContent = `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
    });
  },

  _initCamera() {
    // Fungsi ini tidak berubah, biarkan seperti sebelumnya
    const startCameraBtn = document.querySelector('#start-camera-btn');
    const captureImageBtn = document.querySelector('#capture-image-btn');
    const video = document.querySelector('#camera-preview');
    const canvas = document.querySelector('#camera-canvas');
    const photoInput = document.querySelector('#product-photo');
    let stream = null;

    startCameraBtn.addEventListener('click', async () => {
      try {
        stream = await navigator.mediaDevices.getUserMedia({ video: true });
        video.srcObject = stream;
        video.style.display = 'block';
        captureImageBtn.style.display = 'inline-flex';
        startCameraBtn.style.display = 'none';
      } catch (err) {
        alert('Gagal mengakses kamera. Pastikan Anda memberikan izin.');
        console.error("Error accessing camera: ", err);
      }
    });

    captureImageBtn.addEventListener('click', () => {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);

      canvas.toBlob((blob) => {
        const file = new File([blob], `camera_${Date.now()}.jpg`, { type: 'image/jpeg' });
        
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(file);
        photoInput.files = dataTransfer.files;

        alert('Gambar dari kamera berhasil diambil!');
      }, 'image/jpeg');

      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
      video.style.display = 'none';
      captureImageBtn.style.display = 'none';
      startCameraBtn.style.display = 'inline-flex';
    });
  },
  
  _initFormSubmit() {
    const form = document.querySelector('#add-product-form');
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      
      const productName = document.querySelector('#product-name').value;
      const productDescription = document.querySelector('#product-description').value;
      
      const photo = document.querySelector('#product-photo').files[0];
      const lat = document.querySelector('#latitude').value;
      const lon = document.querySelector('#longitude').value;

      if (!productName || !productDescription || !photo || !lat || !lon) {
        alert('Semua field wajib diisi, termasuk nama, deskripsi, foto, dan memilih lokasi di peta.');
        return;
      }
      
      const fullDescription = `${productName}\n\n${productDescription}`;
      
      try {
        await Api.addNewStory({ description: fullDescription, photo, lat, lon });
        alert('Produk baru berhasil ditambahkan!');
        window.location.hash = '#/products';
      } catch (error) {
        alert(`Gagal menambahkan produk: ${error.message}`);
      }
    });
  }
};

export default AddProductPage;
