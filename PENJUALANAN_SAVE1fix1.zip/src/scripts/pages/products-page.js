import L from 'leaflet';
import Api from '../data/api';

const ProductsPage = {
  async render() {
    return `
      <section class="page-section container">
        <div class="products-header">
          <h2 class="section-title">Koleksi Produk Kami</h2>
          <p class="section-subtitle">Jelajahi semua cerita dan produk yang dibagikan oleh komunitas kami.</p>
        </div>

        <div id="map-container" style="height: 450px; width: 100%; border-radius: 8px; margin-bottom: 3rem; box-shadow: var(--shadow-md);"></div>

        <div id="product-list-container" class="product-list">
          <p>Memuat produk...</p>
        </div>
      </section>
    `;
  },

  async afterRender() {
    const productListContainer = document.querySelector('#product-list-container');
    let map = null; // Variabel untuk menyimpan instance peta

    // Fungsi untuk me-render daftar produk
    const renderProducts = (products) => {
      productListContainer.innerHTML = '';
      if (!products || products.length === 0) {
        productListContainer.innerHTML = '<p class="not-found-message">Belum ada produk untuk ditampilkan.</p>';
        return;
      }
      products.forEach(product => {
        productListContainer.innerHTML += `
          <div class="card product-item">
            <div class="card__image-container">
              <img src="${product.photoUrl}" alt="${product.name}" class="card__image">
            </div>
            <div class="card__content">
              <h3 class="product-item__title">${product.name}</h3>
              <p>${product.description}</p>
              {/* ===== BARIS INI SUDAH BENAR ===== */}
              <p class="product-item__date">Dibuat pada: ${new Date(product.createdAt).toLocaleDateString()}</p>
              <button class="button button--primary button--full">Lihat Detail</button>
            </div>
          </div>
        `;
      });
    };

    // Fungsi untuk menginisialisasi peta dan marker
    const initMap = (products) => {
      // Inisialisasi peta dengan pusat di Indonesia
      map = L.map('map-container').setView([-2.5489, 118.0149], 5);

      // Tambahkan tile layer dari OpenStreetMap
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
      }).addTo(map);

      // Tambahkan marker untuk setiap produk yang memiliki lokasi
      products.forEach(product => {
        if (product.lat && product.lon) {
           // ===== POPUP INI SUDAH BENAR =====
          L.marker([product.lat, product.lon]).addTo(map)
            .bindPopup(`<b>${product.name}</b><br>${product.description.substring(0, 50)}...<br>Dibuat pada: ${new Date(product.createdAt).toLocaleDateString()}`);
        }
      });
    };

    // Ambil data dari API dan render halaman
    try {
      const products = await Api.getAllStories();
      renderProducts(products);
      initMap(products);
    } catch (error) {
      console.error("Gagal memuat produk:", error);
      productListContainer.innerHTML = `<p class="not-found-message">Gagal memuat produk. Error: ${error.message}</p>`;
    }
  },
};

export default ProductsPage;