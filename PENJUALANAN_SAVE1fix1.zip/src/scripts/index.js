// LANGKAH 1: Menghubungkan file CSS ke dalam proyek JavaScript.
// Baris ini SANGAT PENTING agar Vite memuat file style Anda.
import '../styles/styles.css';

// LANGKAH 2: Mengimpor dan menjalankan logika utama aplikasi.
import App from './pages/app';

// Inisialisasi kelas App dengan semua elemen HTML yang dibutuhkan.
const app = new App({
  content: document.querySelector('#main-content'),
  drawerButton: document.querySelector('#drawer-button'),
  navigationDrawer: document.querySelector('#navigation-drawer'),
});

// Event listener untuk merender halaman saat URL hash berubah (navigasi).
window.addEventListener('hashchange', () => {
  app.renderPage();
});

// Event listener untuk merender halaman awal saat semua aset (gambar, dll) selesai dimuat.
window.addEventListener('load', () => {
  app.renderPage();
});

