import { defineConfig } from 'vite';
import { resolve } from 'path';

// https://vitejs.dev/config/
export default defineConfig({
  root: resolve(__dirname, 'src'),
  publicDir: resolve(__dirname, 'src', 'public'),
  build: {
    outDir: resolve(__dirname, 'dist'),
    emptyOutDir: true,
  },
  resolve: {
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },

  // --- TAMBAHKAN BLOK INI UNTUK MENGATASI CORS ---
  server: {
    proxy: {
      // Setiap request yang dimulai dengan '/api' akan diteruskan
      '/api': {
        target: 'https://story-api.dicoding.dev', // API server tujuan
        changeOrigin: true, // Diperlukan untuk virtual host
        rewrite: (path) => path.replace(/^\/api/, ''), // Hapus '/api' dari URL request
      },
    },
  },
});